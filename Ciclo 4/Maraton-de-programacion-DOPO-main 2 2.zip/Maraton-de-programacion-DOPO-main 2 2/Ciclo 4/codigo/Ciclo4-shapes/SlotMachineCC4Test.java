import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Clase de pruebas COMPARTIDA del curso para el Ciclo 4 (tipos de
 * ruedas y de símbolos). Cada pareja agrega aquí mínimo dos casos de
 * prueba sobre los requisitos nuevos de SlotMachine.
 *
 * Convención de nombres:
 *   according<Iniciales>Should<Comportamiento>
 * donde <Iniciales> son las iniciales de los primeros apellidos de
 * los autores, con la primera letra del segundo apellido, en orden
 * alfabético.
 *
 * Agregar aquí los casos de los demás equipos sin borrar los
 * existentes.
 *
 * @author Peralta - Torres
 * @version 1.0
 */
public class SlotMachineCC4Test
{
    private SlotMachine machine;

    /**
     * Crea, antes de cada prueba, una máquina con una rueda normal y
     * una rueda rebel, con los símbolos "cherry", "bell" y "bar" en
     * cada una, en ese orden.
     */
    @Before
    public void setUp()
    {
        machine = new SlotMachine();

        machine.addWheel(1, "normal");
        machine.addWheel(2, "rebel");

        for (int wheel = 1; wheel <= 2; wheel++) {
            machine.addSymbol(wheel, 1, "cherry");
            machine.addSymbol(wheel, 3, "bell");
            machine.addSymbol(wheel, 4, "bar");
        }
    }

    /**
     * NO debería: eliminar una rueda rebel; la máquina conserva todas
     * sus ruedas. (Requisito 17).
     */
    @Test
    public void accordingPaTbShouldNotDeleteARebelWheel()
    {
        machine.delWheel(2);

        assertFalse(machine.ok());
        assertEquals(2, machine.configuration().length);
    }

    /**
     * Debería: hacer que una rueda lefty copie, al girar, el símbolo
     * de la rueda que tiene a su izquierda. (Requisito 17).
     */
    @Test
    public void accordingPaTbShouldCopyLeftNeighborWhenLeftyWheelSpins()
    {
        machine.addWheel(3, "lefty");
        machine.addSymbol(3, 1, "cherry");
        machine.addSymbol(3, 3, "bell");
        machine.addSymbol(3, 4, "bar");
        machine.spin(new String[] {"cherry", "bar", "cherry"});

        machine.spin(3);

        assertTrue(machine.ok());
        assertEquals("bar", machine.configuration()[2]);
    }

    // Agregar aquí los casos de los demás equipos, sin eliminar los anteriores.
}