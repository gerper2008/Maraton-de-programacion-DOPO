import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Pruebas de unidad para los requisitos funcionales agregados en el
 * Ciclo 4 de SlotMachine: tipos de ruedas (normal, lefty, rebel,
 * mirror) y tipos de símbolos (normal, ephemeral, shy, wild).
 *
 * Las pruebas se ejecutan con la máquina en modo INVISIBLE (nunca se
 * llama a makeVisible()).
 *
 * Para cada tipo se probaron dos clases de caso:
 *   - qué SÍ debería hacer (comportamiento propio del tipo)
 *   - qué NO debería hacer (lo que el tipo no permite o no cambia)
 *
 * Los símbolos de cada rueda se agregan siempre en este orden:
 * posición 1 = "cherry", posición 2 = "bell", posición 3 = "bar".
 *
 * @author
 * @version 1.0
 */
public class SlotMachineC4Test
{
    private SlotMachine machine;

    /**
     * Crea, antes de cada prueba, una máquina vacía.
     */
    @Before
    public void setUp()
    {
        machine = new SlotMachine();
    }

    /**
     * Agrega una rueda del tipo indicado al final de la máquina, con
     * los símbolos "cherry", "bell" y "bar" en ese orden.
     *
     * @param type tipo de la rueda (normal, lefty, rebel, mirror).
     */
    private void addFullWheel(String type)
    {
        int pos = machine.configuration().length + 1;
        machine.addWheel(pos, type);
        machine.addSymbol(pos, 1, "cherry");
        machine.addSymbol(pos, 3, "bell");
        machine.addSymbol(pos, 4, "bar");
    }

    // ---------------------------------------------------------------
    // Rueda REBEL  -  Requisito 17
    // ---------------------------------------------------------------

    /**
     * No debería: dejarse eliminar.
     */
    @Test
    public void rebelWheelShouldNotBeDeleted()
    {
        addFullWheel("rebel");

        machine.delWheel(1);

        assertFalse(machine.ok());
        assertEquals(1, machine.configuration().length);
    }

    /**
     * No debería: dejarse intercambiar con otra rueda.
     */
    @Test
    public void rebelWheelShouldNotBeSwapped()
    {
        addFullWheel("normal");
        addFullWheel("rebel");
        machine.spin(new String[] {"cherry", "bar"});

        machine.swap(1, 2);

        assertFalse(machine.ok());
        assertArrayEquals(new String[] {"cherry", "bar"},
                          machine.configuration());
    }

    /**
     * No debería: quedar bloqueada; después de lock sigue girando.
     */
    @Test
    public void rebelWheelShouldKeepSpinningAfterLock()
    {
        addFullWheel("rebel");
        machine.spin(new String[] {"cherry"});

        machine.lock(1);
        machine.spin(1);

        assertTrue(machine.ok());
        assertArrayEquals(new String[] {"bell"}, machine.configuration());
    }

    /**
     * Debería: una rueda normal sí dejarse eliminar (contraste con
     * la rebel).
     */
    @Test
    public void normalWheelShouldBeDeleted()
    {
        addFullWheel("normal");

        machine.delWheel(1);

        assertTrue(machine.ok());
        assertEquals(0, machine.configuration().length);
    }

    // ---------------------------------------------------------------
    // Rueda LEFTY  -  Requisito 17
    // ---------------------------------------------------------------

    /**
     * Debería: al girar, copiar el símbolo de la rueda a su izquierda.
     */
    @Test
    public void leftyWheelShouldCopyItsLeftNeighborWhenSpinning()
    {
        addFullWheel("normal");
        addFullWheel("lefty");
        machine.spin(new String[] {"bar", "cherry"});

        machine.spin(2);

        assertTrue(machine.ok());
        assertArrayEquals(new String[] {"bar", "bar"},
                          machine.configuration());
    }

    /**
     * Debería: en spin() general, copiar el estado que su vecina tiene
     * DESPUÉS de girar.
     */
    @Test
    public void leftyWheelShouldCopyNeighborAfterSpinAll()
    {
        addFullWheel("normal");
        addFullWheel("lefty");
        machine.spin(new String[] {"cherry", "cherry"});

        machine.spin();

        assertArrayEquals(new String[] {"bell", "bell"},
                          machine.configuration());
    }

    /**
     * Debería: si no tiene rueda a su izquierda, girar como una normal.
     */
    @Test
    public void leftyWheelWithoutLeftNeighborShouldSpinNormally()
    {
        addFullWheel("lefty");
        machine.spin(new String[] {"cherry"});

        machine.spin(1);

        assertArrayEquals(new String[] {"bell"}, machine.configuration());
    }

    /**
     * No debería: cambiar si la vecina muestra un símbolo que la
     * lefty no tiene.
     */
    @Test
    public void leftyWheelShouldNotChangeIfNeighborSymbolIsMissing()
    {
        machine.addWheel(1, "normal");
        machine.addSymbol(1, 2, "seven");
        addFullWheel("lefty");
        machine.spin(new String[] {"seven", "bell"});

        machine.spin(2);

        assertArrayEquals(new String[] {"seven", "bell"},
                          machine.configuration());
    }

    // ---------------------------------------------------------------
    // Rueda MIRROR (tipo propuesto)  -  Requisito 19
    // ---------------------------------------------------------------

    /**
     * Debería: girar en sentido contrario a una rueda normal.
     */
    @Test
    public void mirrorWheelShouldSpinBackwards()
    {
        addFullWheel("normal");
        addFullWheel("mirror");
        machine.spin(new String[] {"cherry", "cherry"});

        machine.spin(1);
        machine.spin(2);

        assertArrayEquals(new String[] {"bell", "bar"},
                          machine.configuration());
    }

    /**
     * No debería: girar si está bloqueada (sí respeta lock).
     */
    @Test
    public void mirrorWheelShouldNotSpinWhenLocked()
    {
        addFullWheel("mirror");
        machine.spin(new String[] {"cherry"});

        machine.lock(1);
        machine.spin(1);

        assertFalse(machine.ok());
        assertArrayEquals(new String[] {"cherry"}, machine.configuration());
    }

    // ---------------------------------------------------------------
    // Símbolo EPHEMERAL  -  Requisito 18
    // ---------------------------------------------------------------

    /**
     * Debería: reducir su tamaño en cada giro de su rueda.
     */
    @Test
    public void ephemeralSymbolShouldShrinkOnEachSpin()
    {
        Wheel wheel = new Wheel();
        EphemeralSymbol ephemeral = new EphemeralSymbol("ghost", "red");
        wheel.addSymbol(ephemeral, 1);
        wheel.addSymbol(new Symbol("bell", "yellow"), 2);
        int before = ephemeral.getCurrentSize();

        wheel.spin();

        assertTrue(ephemeral.getCurrentSize() < before);
    }

    /**
     * No debería: desaparecer del todo; tras muchos giros queda como
     * un punto (tamaño mínimo mayor que cero).
     */
    @Test
    public void ephemeralSymbolShouldNotShrinkBelowAPoint()
    {
        Wheel wheel = new Wheel();
        EphemeralSymbol ephemeral = new EphemeralSymbol("ghost", "red");
        wheel.addSymbol(ephemeral, 1);
        wheel.addSymbol(new Symbol("bell", "yellow"), 2);

        for (int i = 0; i < 50; i++) {
            wheel.spin();
        }

        int size = ephemeral.getCurrentSize();
        assertTrue(size > 0);
        wheel.spin();
        assertEquals(size, ephemeral.getCurrentSize());
    }

    /**
     * No debería: un símbolo normal cambiar de tamaño al girar.
     */
    @Test
    public void normalSymbolShouldNotChangeSizeWhenSpinning()
    {
        Wheel wheel = new Wheel();
        Symbol normal = new Symbol("cherry", "red");
        wheel.addSymbol(normal, 1);
        wheel.addSymbol(new Symbol("bell", "yellow"), 2);
        int before = normal.getCurrentSize();

        wheel.spin();
        wheel.spin();

        assertEquals(before, normal.getCurrentSize());
    }

    // ---------------------------------------------------------------
    // Símbolo SHY  -  Requisito 18
    // ---------------------------------------------------------------

    /**
     * Debería: alternar entre visible e invisible cada vez que queda
     * seleccionado en la rueda.
     */
    @Test
    public void shySymbolShouldToggleEachTimeItIsSelected()
    {
        Wheel wheel = new Wheel();
        ShySymbol shy = new ShySymbol("shy", "blue");
        wheel.addSymbol(new Symbol("cherry", "red"), 1);
        wheel.addSymbol(shy, 2);
        assertTrue(shy.shouldDisplay());

        wheel.spin();
        assertFalse(shy.shouldDisplay());

        wheel.spin();
        wheel.spin();
        assertTrue(shy.shouldDisplay());
    }

    /**
     * No debería: cambiar su estado si la rueda gira pero no lo
     * selecciona.
     */
    @Test
    public void shySymbolShouldNotToggleIfNotSelected()
    {
        Wheel wheel = new Wheel();
        ShySymbol shy = new ShySymbol("shy", "blue");
        wheel.addSymbol(new Symbol("cherry", "red"), 1);
        wheel.addSymbol(shy, 2);
        wheel.addSymbol(new Symbol("bar", "green"), 3);

        wheel.spin(2);

        assertTrue(shy.shouldDisplay());
    }

    // ---------------------------------------------------------------
    // Símbolo WILD (tipo propuesto)  -  Requisito 19
    // ---------------------------------------------------------------

    /**
     * Debería: contar como cualquier símbolo para el jackpot.
     */
    @Test
    public void wildSymbolShouldCompleteJackpot()
    {
        addFullWheel("normal");
        addFullWheel("normal");
        addFullWheel("normal");
        machine.addSymbol(2, 5, "joker", "wild");

        machine.spin(new String[] {"cherry", "joker", "cherry"});

        assertTrue(machine.ok());
        assertTrue(machine.isJackpot());
    }

    /**
     * No debería: dar jackpot si los demás símbolos son distintos.
     */
    @Test
    public void wildSymbolShouldNotMakeJackpotWithDifferentSymbols()
    {
        addFullWheel("normal");
        addFullWheel("normal");
        addFullWheel("normal");
        machine.addSymbol(2, 5, "joker", "wild");

        machine.spin(new String[] {"cherry", "joker", "bell"});

        assertFalse(machine.isJackpot());
    }

    // ---------------------------------------------------------------
    // Creación por tipo  -  Requisito 16
    // ---------------------------------------------------------------

    /**
     * Debería: aceptar todos los tipos de símbolos en una misma rueda.
     */
    @Test
    public void shouldAddSymbolsOfEveryType()
    {
        machine.addWheel(1, "normal");
        machine.addSymbol(1, 1, "a", "normal");
        machine.addSymbol(1, 2, "b", "ephemeral");
        machine.addSymbol(1, 3, "c", "shy");
        machine.addSymbol(1, 4, "d", "wild");

        assertTrue(machine.ok());
        assertEquals(4, machine.symbols().length);
    }

    /**
     * No debería: agregar un símbolo tipado a una rueda que no existe.
     */
    @Test
    public void shouldNotAddTypedSymbolToMissingWheel()
    {
        machine.addWheel(1, "normal");

        machine.addSymbol(5, 1, "ghost", "ephemeral");

        assertFalse(machine.ok());
        assertEquals(0, machine.symbols().length);
    }
}